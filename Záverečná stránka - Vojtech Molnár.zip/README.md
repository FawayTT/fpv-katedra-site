# fpv-katedra-site
 
link: http://katedrainf-zaverecna-stranka.6f.sk/